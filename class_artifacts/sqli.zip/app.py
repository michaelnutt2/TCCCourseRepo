import sqlite3
from flask import Flask, request, render_template_string

app = Flask(__name__)
DB_PATH = "users.db"

LOGIN_PAGE = """
<!DOCTYPE html>
<html>
<head>
    <title>Northgate Internal Portal</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f3f4f6; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .card { background: white; padding: 40px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); width: 320px; }
        h2 { margin-top: 0; color: #1f2937; }
        input { width: 100%; padding: 10px; margin: 8px 0; box-sizing: border-box; border: 1px solid #d1d5db; border-radius: 4px; }
        button { width: 100%; padding: 10px; background: #2563eb; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 14px; }
        button:hover { background: #1d4ed8; }
        .msg { margin-top: 16px; padding: 10px; border-radius: 4px; font-size: 14px; }
        .error { background: #fef2f2; color: #991b1b; }
        .success { background: #f0fdf4; color: #166534; }
    </style>
</head>
<body>
    <div class="card">
        <h2>Internal Portal Login</h2>
        <form method="POST" action="/login">
            <input type="text" name="username" placeholder="Username" required>
            <input type="text" name="password" placeholder="Password" required>
            <button type="submit">Log In</button>
        </form>
        {% if message %}
        <div class="msg {{ msg_class }}">{{ message }}</div>
        {% endif %}
    </div>
</body>
</html>
"""

DASHBOARD_PAGE = """
<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f3f4f6; padding: 40px; }
        .card { background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); max-width: 600px; margin: auto; }
        h2 { color: #166534; }
        table { width: 100%; border-collapse: collapse; margin-top: 16px; }
        th, td { padding: 8px; text-align: left; border-bottom: 1px solid #e5e7eb; font-size: 13px; }
        th { background: #f9fafb; }
    </style>
</head>
<body>
    <div class="card">
        <h2>&#9989; Access Granted: Welcome, {{ username }}</h2>
        <p>You are viewing the internal admin dashboard.</p>
        <table>
            <tr><th>Username</th><th>Role</th><th>Email</th></tr>
            {% for row in rows %}
            <tr><td>{{ row[0] }}</td><td>{{ row[1] }}</td><td>{{ row[2] }}</td></tr>
            {% endfor %}
        </table>
    </div>
</body>
</html>
"""

def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("DROP TABLE IF EXISTS users")
    c.execute("""
        CREATE TABLE users (
            id INTEGER PRIMARY KEY,
            username TEXT,
            password TEXT,
            role TEXT,
            email TEXT
        )
    """)
    c.execute("INSERT INTO users (username, password, role, email) VALUES ('admin', 'Tr0ub4dor&3', 'administrator', 'admin@northgate-mfg.local')")
    c.execute("INSERT INTO users (username, password, role, email) VALUES ('jsmith', 'summer2024', 'employee', 'jsmith@northgate-mfg.local')")
    c.execute("INSERT INTO users (username, password, role, email) VALUES ('mrodriguez', 'password1', 'employee', 'mrodriguez@northgate-mfg.local')")
    conn.commit()
    conn.close()

@app.route("/")
def index():
    return render_template_string(LOGIN_PAGE, message=None)

@app.route("/login", methods=["POST"])
def login():
    username = request.form.get("username", "")
    password = request.form.get("password", "")

    # INTENTIONALLY VULNERABLE: user input concatenated directly into the SQL string.
    # This mirrors the exact pattern shown in the course textbook's PHP example.
    query = "SELECT username, role, email FROM users WHERE username='" + username + "' AND password='" + password + "';"

    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    try:
        c.execute(query)
        rows = c.fetchall()
    except sqlite3.OperationalError as e:
        conn.close()
        return render_template_string(LOGIN_PAGE, message=f"Database error: {e}", msg_class="error")
    conn.close()

    if rows:
        return render_template_string(DASHBOARD_PAGE, username=username, rows=rows)
    else:
        return render_template_string(LOGIN_PAGE, message="Invalid username or password.", msg_class="error")

if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=5000, debug=False)
