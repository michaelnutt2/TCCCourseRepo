import sqlite3
from flask import Flask, request, render_template_string

app = Flask(__name__)
DB_PATH = "users.db"

LOGIN_PAGE = """
<!DOCTYPE html>
<html>
<head>
    <title>Northgate Internal Portal</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f3f4f6; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .card { background: white; padding: 40px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); width: 340px; }
        h2 { margin-top: 0; color: #1f2937; }
        input { width: 100%; padding: 10px; margin: 8px 0; box-sizing: border-box; border: 1px solid #d1d5db; border-radius: 4px; font-family: monospace; }
        button { width: 100%; padding: 10px; background: #2563eb; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 14px; }
        button:hover { background: #1d4ed8; }
        .msg { margin-top: 16px; padding: 10px; border-radius: 4px; font-size: 14px; }
        .error { background: #fef2f2; color: #991b1b; }
        .db-error { background: #fefce8; color: #854d0e; font-family: monospace; font-size: 12px; white-space: pre-wrap; }
    </style>
</head>
<body>
    <div class="card">
        <h2>Internal Portal Login</h2>
        <form method="POST" action="/login">
            <input type="text" name="username" placeholder="Username" autocomplete="off" required>
            <input type="text" name="password" placeholder="Password" autocomplete="off" required>
            <button type="submit">Log In</button>
        </form>
        {% if message %}
        <div class="msg {{ msg_class }}">{{ message }}</div>
        {% endif %}
    </div>
</body>
</html>
"""

DASHBOARD_PAGE = """
<!DOCTYPE html>
<html>
<head>
    <title>Portal — Query Result</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f3f4f6; padding: 40px; }
        .card { background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); max-width: 800px; margin: auto; }
        h2 { color: #166534; margin-top: 0; }
        .query-box { background: #1f2937; color: #d1fae5; padding: 12px 16px; border-radius: 4px; font-family: monospace; font-size: 13px; margin-bottom: 20px; word-break: break-all; }
        table { width: 100%; border-collapse: collapse; margin-top: 16px; }
        th, td { padding: 8px 12px; text-align: left; border-bottom: 1px solid #e5e7eb; font-size: 13px; word-break: break-all; }
        th { background: #f9fafb; font-weight: 600; color: #374151; }
        tr:hover { background: #f0fdf4; }
        .row-count { font-size: 12px; color: #6b7280; margin-top: 10px; }
        a { display: inline-block; margin-top: 20px; color: #2563eb; font-size: 13px; }
    </style>
</head>
<body>
    <div class="card">
        <h2>&#9989; Query Executed Successfully</h2>
        <p style="font-size:13px; color:#374151;">Logged in as: <strong>{{ username }}</strong></p>
        <div class="query-box">{{ query }}</div>
        {% if rows %}
        <table>
            <tr>{% for h in headers %}<th>{{ h }}</th>{% endfor %}</tr>
            {% for row in rows %}
            <tr>{% for cell in row %}<td>{{ cell }}</td>{% endfor %}</tr>
            {% endfor %}
        </table>
        <div class="row-count">{{ rows|length }} row(s) returned</div>
        {% else %}
        <p style="color:#6b7280; font-size:13px;">Query returned no rows.</p>
        {% endif %}
        <a href="/">&larr; Back to login</a>
    </div>
</body>
</html>
"""

def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("DROP TABLE IF EXISTS users")
    c.execute("""
        CREATE TABLE users (
            id INTEGER PRIMARY KEY,
            username TEXT,
            password TEXT,
            role TEXT,
            email TEXT
        )
    """)
    c.execute("INSERT INTO users VALUES (1,'admin','Tr0ub4dor&3','administrator','admin@northgate-mfg.local')")
    c.execute("INSERT INTO users VALUES (2,'jsmith','summer2024','employee','jsmith@northgate-mfg.local')")
    c.execute("INSERT INTO users VALUES (3,'mrodriguez','password1','employee','mrodriguez@northgate-mfg.local')")
    conn.commit()
    conn.close()

def get_column_names(cursor):
    """Return column names from cursor description, or generic col0/col1/... if not available."""
    if cursor.description:
        return [d[0] for d in cursor.description]
    return []

@app.route("/")
def index():
    return render_template_string(LOGIN_PAGE, message=None)

@app.route("/login", methods=["POST"])
def login():
    username = request.form.get("username", "")
    password = request.form.get("password", "")

    # INTENTIONALLY VULNERABLE: user input concatenated directly into the SQL string.
    # Column count is 3 (username, role, email) — UNION injections must also select 3 columns.
    query = "SELECT username, role, email FROM users WHERE username='" + username + "' AND password='" + password + "'"

    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    try:
        c.execute(query)
        rows = c.fetchall()
        headers = get_column_names(c)
    except sqlite3.OperationalError as e:
        conn.close()
        # Show the actual database error — intentional for the lab so students can
        # read error messages as a recon tool (just like a real misconfigured app would).
        return render_template_string(LOGIN_PAGE,
            message=f"Database error:\n{e}\n\nQuery attempted:\n{query}",
            msg_class="db-error")
    conn.close()

    if rows:
        return render_template_string(DASHBOARD_PAGE,
            username=username,
            query=query,
            headers=headers,
            rows=rows)
    else:
        return render_template_string(LOGIN_PAGE,
            message="Invalid username or password.",
            msg_class="error")

if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=5000, debug=False)
